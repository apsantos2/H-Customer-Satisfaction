(function($) {

	// Group expand/collapse button
	$("span.ewGroupToggle").on("click", function() {
		ewr_ToggleGroup(this);
	});

	// Field event handlers
})(jQuery);
